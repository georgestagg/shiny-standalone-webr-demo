# unknown hyperlink type

    Code
      make_link("this", "foobar")
    Condition
      Error in `match.arg()`:
      ! 'arg' should be one of "email", "file", "fun", "help", "href", "run", "topic", "url", "vignette"

