library(testthat)
library(cli)

test_check("cli")
