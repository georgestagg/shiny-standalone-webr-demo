This a small patch release at the request of Luke Tierney.

All that has changed is a test.

