declare function disableFormSubmission(): void;
export { disableFormSubmission };
