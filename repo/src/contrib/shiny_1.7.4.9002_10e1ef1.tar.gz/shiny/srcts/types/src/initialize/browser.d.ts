declare function determineBrowserInfo(): void;
export { determineBrowserInfo };
