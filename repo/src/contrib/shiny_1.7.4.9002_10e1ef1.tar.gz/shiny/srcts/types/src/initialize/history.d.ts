declare function trackHistory(): void;
export { trackHistory };
