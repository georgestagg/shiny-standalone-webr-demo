declare function disableDrag($el: JQuery<HTMLElement>, $img: JQuery<HTMLElement>): void;
export { disableDrag };
