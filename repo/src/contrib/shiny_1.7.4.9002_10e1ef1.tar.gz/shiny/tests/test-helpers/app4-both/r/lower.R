lowerHelper <- 123
