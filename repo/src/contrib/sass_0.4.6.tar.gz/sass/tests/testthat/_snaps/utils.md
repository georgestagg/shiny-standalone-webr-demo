# join_non_null_values combines null elements as expected

    Code
      obj
    Output
      /* Sass Bundle */
      $color: blue;
      .rule-b {}
      .rule-a {}
      .rule-c {}
      /* *** */

