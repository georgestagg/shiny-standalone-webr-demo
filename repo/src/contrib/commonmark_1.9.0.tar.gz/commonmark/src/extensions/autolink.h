#ifndef CMARK_GFM_AUTOLINK_H
#define CMARK_GFM_AUTOLINK_H

#include "cmark-gfm-core-extensions.h"

cmark_syntax_extension *create_autolink_extension(void);

#endif
